/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;


import common.Message;
import common.GameState;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class GameServer {
    

     private static final int PORT = 5000;

    private static ArrayList<ClientHandler> clients = new ArrayList<>();
    private static GameState gameState = new GameState();

    public static void main(String[] args) {

        try {

            ServerSocket serverSocket = new ServerSocket(PORT);

            System.out.println("Server started...");
            System.out.println("Waiting for players...");

            while (clients.size() < 2) {

                Socket socket = serverSocket.accept();

                int playerId = clients.size() + 1;

                ClientHandler clientHandler =
                        new ClientHandler(socket, playerId);

                clients.add(clientHandler);

                clientHandler.start();

                System.out.println("Player "
                        + playerId + " connected.");

            }

            System.out.println("Two players connected.");
            System.out.println("Game can start.");

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    static class ClientHandler extends Thread {

        private Socket socket;
        private int playerId;

        private ObjectInputStream input;
        private ObjectOutputStream output;

        public ClientHandler(Socket socket, int playerId) {

            this.socket = socket;
            this.playerId = playerId;

            try {

                output = new ObjectOutputStream(
                        socket.getOutputStream());

                input = new ObjectInputStream(
                        socket.getInputStream());

                Message message =
                        new Message("PLAYER_ID");

                message.playerId = playerId;

                output.writeObject(message);

            } catch (Exception e) {

                e.printStackTrace();

            }

        }

        @Override
        public void run() {

            try {

              while (true) {

    Message message =
            (Message) input.readObject();

    if (message.type.equals("ROLL")) {

        if (gameState.currentTurn == playerId) {

            int dice =
                    (int) (Math.random() * 6) + 1;

            int newPosition =
                    gameState.movePlayer(
                            playerId,
                            dice);

            Message update =
                    new Message("UPDATE");

            update.playerId = playerId;
            update.dice = dice;

            update.player1Position =
                    gameState.player1Position;

            update.player2Position =
                    gameState.player2Position;

            update.currentTurn =
                    (playerId == 1) ? 2 : 1;

            gameState.currentTurn =
                    update.currentTurn;

            if (gameState.gameOver) {

                update.gameOver = true;

                update.winner =
                        "Player " + playerId;

            }

            broadcast(update);

            System.out.println(
                    "Player "
                            + playerId
                            + " rolled "
                            + dice);

            System.out.println(
                    "P1 Position: "
                            + gameState.player1Position);

            System.out.println(
                    "P2 Position: "
                            + gameState.player2Position);

        }

    }
if (message.type.equals("RESET")) {

    gameState.resetGame();

    Message resetMessage = new Message("UPDATE");

    resetMessage.player1Position = gameState.player1Position;
    resetMessage.player2Position = gameState.player2Position;
    resetMessage.currentTurn = gameState.currentTurn;
    resetMessage.gameOver = false;
    resetMessage.text = "New game started.";

    broadcast(resetMessage);

    System.out.println("Game reset by Player " + playerId);
}
}

            } catch (Exception e) {

                System.out.println(
                        "Player "
                                + playerId
                                + " disconnected.");

            }

        }

    }
    
public static void broadcast(Message message) {

    for (ClientHandler client : clients) {

        try {

            client.output.writeObject(message);
            client.output.flush();

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

}
}
