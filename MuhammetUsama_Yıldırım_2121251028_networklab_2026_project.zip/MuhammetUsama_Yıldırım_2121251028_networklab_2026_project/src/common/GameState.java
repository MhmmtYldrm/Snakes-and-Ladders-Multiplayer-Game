package common;

import java.util.HashMap;

public class GameState {

    public int player1Position = 1;
    public int player2Position = 1;

    public int currentTurn = 1;

    public boolean gameOver = false;

    public HashMap<Integer, Integer> snakes = new HashMap<>();
    public HashMap<Integer, Integer> ladders = new HashMap<>();

    public GameState() {
        initializeBoard();
    }

    private void initializeBoard() {

        ladders.clear();
        snakes.clear();

        // Ladders
        ladders.put(4, 14);
        ladders.put(9, 31);
        ladders.put(20, 38);
        ladders.put(28, 84);
        ladders.put(40, 59);
        ladders.put(51, 67);
        ladders.put(63, 81);

        // Snakes
        snakes.put(17, 7);
        snakes.put(54, 34);
        snakes.put(62, 19);
        snakes.put(64, 60);
        snakes.put(87, 24);
        snakes.put(93, 73);
        snakes.put(95, 75);
        snakes.put(99, 78);
    }

    public int movePlayer(int playerId, int dice) {

        int position;

        if (playerId == 1) {
            player1Position += dice;
            position = player1Position;
        } else {
            player2Position += dice;
            position = player2Position;
        }

        if (position > 100) {
            position = 100;
        }

        if (snakes.containsKey(position)) {
            position = snakes.get(position);
        }

        if (ladders.containsKey(position)) {
            position = ladders.get(position);
        }

        if (playerId == 1) {
            player1Position = position;
        } else {
            player2Position = position;
        }

        if (position >= 100) {
            gameOver = true;
        }

        return position;
    }

    public void resetGame() {
        player1Position = 1;
        player2Position = 1;
        currentTurn = 1;
        gameOver = false;
        initializeBoard();
    }
}