/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package common;

import java.io.Serializable;

public class Message implements Serializable {

    private static final long serialVersionUID = 1L;

    public String type;
    public String text;
    public int playerId;
    public int dice;
    public int player1Position;
    public int player2Position;
    public boolean gameOver;

    public int currentTurn;
    public String winner;

    public Message(String type) {
        this.type = type;
    }
}
