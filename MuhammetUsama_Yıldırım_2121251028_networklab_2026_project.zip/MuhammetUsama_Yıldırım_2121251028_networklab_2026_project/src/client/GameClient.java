package client;

import common.Message;
import ui.GameBoard;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import ui.StartScreen;

public class GameClient {

   private static final String SERVER_IP = "127.0.0.1";
private static final int PORT = 5000;

    private static int playerId;

    private static ObjectOutputStream output;

    private static GameBoard board;

    public static void main(String[] args) {

        try {

            Socket socket =
                    new Socket(SERVER_IP, PORT);

            output =
                    new ObjectOutputStream(
                            socket.getOutputStream());

            ObjectInputStream input =
                    new ObjectInputStream(
                            socket.getInputStream());

            Message firstMessage =
                    (Message) input.readObject();

            if (firstMessage.type.equals("PLAYER_ID")) {

                playerId =
                        firstMessage.playerId;

                System.out.println(
                        "You are Player "
                                + playerId);

            }
StartScreen startScreen =
        new StartScreen();

final boolean[] started =
        {false};

startScreen.getStartButton().addActionListener(e -> {
    started[0] = true;
    startScreen.dispose();
});

while (!started[0]) {
    Thread.sleep(100);
}
            board = new GameBoard();
            board.getRollButton().setEnabled(playerId == 1);

            board.setInfo(
                    "You are Player "
                            + playerId);

            board.getRollButton().addActionListener(e -> {

                try {

                    Message rollMessage =
                            new Message("ROLL");

                    rollMessage.playerId =
                            playerId;

                    output.writeObject(rollMessage);

                    output.flush();

                } catch (Exception ex) {

                    ex.printStackTrace();

                }

            });

            while (true) {

                Message message =
                        (Message) input.readObject();

                if (message.type.equals("UPDATE")) {

                    board.updateBoard(
                            message.player1Position,
                            message.player2Position);
                    board.setDice(message.dice);

                    board.setInfo(
                            "Player "
                                    + message.playerId
                                    + " rolled "
                                    + message.dice
                                    + " | Current Turn: Player "
                                    + message.currentTurn);
                    if (message.currentTurn == playerId && !message.gameOver) {
    board.getRollButton().setEnabled(true);
} else {
    board.getRollButton().setEnabled(false);
}

                  if (message.gameOver) {

    board.setInfo(
            "GAME OVER - Winner: "
                    + message.winner);

    javax.swing.JOptionPane.showMessageDialog(
            board,
            "Winner: " + message.winner,
            "GAME OVER",
            javax.swing.JOptionPane.INFORMATION_MESSAGE);

    int choice =
            javax.swing.JOptionPane.showConfirmDialog(
                    board,
                    "Do you want to play again?",
                    "Replay",
                    javax.swing.JOptionPane.YES_NO_OPTION);

   if (choice ==
        javax.swing.JOptionPane.YES_OPTION) {

    Message resetMessage =
            new Message("RESET");

    resetMessage.playerId =
            playerId;

    output.writeObject(resetMessage);
    output.flush();

} else {

    System.exit(0);

}

}

                }

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

}