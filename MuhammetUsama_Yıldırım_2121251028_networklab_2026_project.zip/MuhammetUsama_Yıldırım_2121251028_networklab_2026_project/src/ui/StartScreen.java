package ui;

import javax.swing.*;
import java.awt.*;

public class StartScreen extends JFrame {

    private JButton startButton;

    public StartScreen() {

        setTitle("Snakes and Ladders - Start");
        setSize(600, 420);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(50, 25, 10));
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(45, 30, 45, 30));

        JLabel title = new JLabel("🐍 SNAKES & LADDERS 🪜", SwingConstants.CENTER);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setFont(new Font("Serif", Font.BOLD, 38));
        title.setForeground(new Color(255, 215, 80));

        JLabel subtitle = new JLabel("Java Socket Multiplayer Game", SwingConstants.CENTER);
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        subtitle.setFont(new Font("Arial", Font.BOLD, 18));
        subtitle.setForeground(Color.WHITE);

        JLabel players = new JLabel("Oyuncu 1: AT ♞     |     Oyuncu 2: FİL 🐘", SwingConstants.CENTER);
        players.setAlignmentX(Component.CENTER_ALIGNMENT);
        players.setFont(new Font("Arial", Font.BOLD, 18));
        players.setForeground(new Color(220, 220, 220));

        startButton = new JButton("OYUNA BAĞLAN");
        startButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        startButton.setFont(new Font("Arial", Font.BOLD, 24));
        startButton.setBackground(new Color(40, 165, 70));
        startButton.setForeground(Color.WHITE);
        startButton.setFocusPainted(false);

        mainPanel.add(title);
        mainPanel.add(Box.createVerticalStrut(25));
        mainPanel.add(subtitle);
        mainPanel.add(Box.createVerticalStrut(45));
        mainPanel.add(players);
        mainPanel.add(Box.createVerticalStrut(45));
        mainPanel.add(startButton);

        add(mainPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    public JButton getStartButton() {
        return startButton;
    }
}