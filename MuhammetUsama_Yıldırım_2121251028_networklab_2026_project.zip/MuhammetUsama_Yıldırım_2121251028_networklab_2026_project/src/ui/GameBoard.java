package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.QuadCurve2D;
import java.util.HashMap;
import java.util.Map;

public class GameBoard extends JFrame {

    private BoardCanvas boardCanvas;

    private JButton rollButton;
    private JLabel infoLabel;
    private JLabel diceLabel;
    private JLabel horseInfo;
    private JLabel elephantInfo;

    public GameBoard() {

        setTitle("Snakes and Ladders - Çok Oyunculu");
        setSize(1150, 820);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        add(createHeader(), BorderLayout.NORTH);
        add(createLeftPanel(), BorderLayout.WEST);
        add(createRightPanel(), BorderLayout.EAST);
        add(createBottomPanel(), BorderLayout.SOUTH);

        boardCanvas = new BoardCanvas();
        add(boardCanvas, BorderLayout.CENTER);

        updateBoard(0, 0);

        setVisible(true);
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(50, 25, 10));
        header.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel title = new JLabel("🐍 SNAKES & LADDERS 🪜", SwingConstants.CENTER);
        title.setFont(new Font("Serif", Font.BOLD, 38));
        title.setForeground(new Color(255, 215, 80));

        JLabel subtitle = new JLabel("ÇOK OYUNCULU JAVA NETWORK OYUNU", SwingConstants.CENTER);
        subtitle.setFont(new Font("Arial", Font.BOLD, 15));
        subtitle.setForeground(Color.WHITE);

        header.add(title, BorderLayout.CENTER);
        header.add(subtitle, BorderLayout.SOUTH);

        return header;
    }

    private JPanel createLeftPanel() {
        JPanel panel = new JPanel();
        panel.setPreferredSize(new Dimension(230, 0));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(20, 25, 40));
        panel.setBorder(BorderFactory.createEmptyBorder(25, 15, 25, 15));

        JLabel title = new JLabel("OYUNCU 1", SwingConstants.CENTER);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(new Color(70, 170, 255));

        JLabel avatar = new JLabel("♞", SwingConstants.CENTER);
        avatar.setAlignmentX(Component.CENTER_ALIGNMENT);
        avatar.setFont(new Font("Serif", Font.BOLD, 95));
        avatar.setForeground(new Color(70, 170, 255));

        JLabel name = new JLabel("AT", SwingConstants.CENTER);
        name.setAlignmentX(Component.CENTER_ALIGNMENT);
        name.setFont(new Font("Arial", Font.BOLD, 30));
        name.setForeground(Color.WHITE);

        horseInfo = new JLabel("Konum: 1", SwingConstants.CENTER);
        horseInfo.setAlignmentX(Component.CENTER_ALIGNMENT);
        horseInfo.setFont(new Font("Arial", Font.BOLD, 20));
        horseInfo.setForeground(new Color(160, 215, 255));

        panel.add(title);
        panel.add(Box.createVerticalStrut(35));
        panel.add(avatar);
        panel.add(name);
        panel.add(Box.createVerticalStrut(35));
        panel.add(horseInfo);

        return panel;
    }

    private JPanel createRightPanel() {
        JPanel panel = new JPanel();
        panel.setPreferredSize(new Dimension(230, 0));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(45, 20, 20));
        panel.setBorder(BorderFactory.createEmptyBorder(25, 15, 25, 15));

        JLabel title = new JLabel("OYUNCU 2", SwingConstants.CENTER);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(new Color(255, 110, 110));

        JLabel avatar = new JLabel("🐘", SwingConstants.CENTER);
        avatar.setAlignmentX(Component.CENTER_ALIGNMENT);
        avatar.setFont(new Font("Serif", Font.BOLD, 75));

        JLabel name = new JLabel("FİL", SwingConstants.CENTER);
        name.setAlignmentX(Component.CENTER_ALIGNMENT);
        name.setFont(new Font("Arial", Font.BOLD, 30));
        name.setForeground(Color.WHITE);

        elephantInfo = new JLabel("Konum: 1", SwingConstants.CENTER);
        elephantInfo.setAlignmentX(Component.CENTER_ALIGNMENT);
        elephantInfo.setFont(new Font("Arial", Font.BOLD, 20));
        elephantInfo.setForeground(new Color(255, 170, 170));

        diceLabel = new JLabel("🎲", SwingConstants.CENTER);
        diceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        diceLabel.setFont(new Font("Serif", Font.BOLD, 70));

        rollButton = new JButton("ZAR AT");
        rollButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        rollButton.setFont(new Font("Arial", Font.BOLD, 24));
        rollButton.setBackground(new Color(40, 165, 70));
        rollButton.setForeground(Color.WHITE);
        rollButton.setFocusPainted(false);

        panel.add(title);
        panel.add(Box.createVerticalStrut(35));
        panel.add(avatar);
        panel.add(name);
        panel.add(Box.createVerticalStrut(35));
        panel.add(elephantInfo);
        panel.add(Box.createVerticalStrut(55));
        panel.add(diceLabel);
        panel.add(Box.createVerticalStrut(20));
        panel.add(rollButton);

        return panel;
    }

    private JPanel createBottomPanel() {
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBackground(new Color(50, 25, 10));
        bottom.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));

        infoLabel = new JLabel("Sunucuya bağlanılıyor...", SwingConstants.CENTER);
        infoLabel.setFont(new Font("Arial", Font.BOLD, 19));
        infoLabel.setForeground(Color.WHITE);

        bottom.add(infoLabel, BorderLayout.CENTER);

        return bottom;
    }

    public void updateBoard(int p1Position, int p2Position) {
        int horsePosition = Math.max(1, Math.min(100, p1Position));
        int elephantPosition = Math.max(1, Math.min(100, p2Position));

        boardCanvas.setPositions(horsePosition, elephantPosition);

        horseInfo.setText("Konum: " + horsePosition);
        elephantInfo.setText("Konum: " + elephantPosition);
    }

    public JButton getRollButton() {
        return rollButton;
    }

    public void setInfo(String text) {
        infoLabel.setText(text);
    }

    public void setDice(int dice) {
        diceLabel.setText("🎲 " + dice);
    }

    private static class BoardCanvas extends JPanel {

        private int horsePosition = 1;
        private int elephantPosition = 1;

        private final Map<Integer, Integer> ladders = new HashMap<>();
        private final Map<Integer, Integer> snakes = new HashMap<>();

        public BoardCanvas() {
            setBackground(new Color(70, 38, 12));

            ladders.put(4, 14);
            ladders.put(9, 31);
            ladders.put(20, 38);
            ladders.put(28, 44);
            ladders.put(40, 59);
            ladders.put(51, 67);
            ladders.put(56, 75);
            ladders.put(63, 81);

            snakes.put(17, 7);
            snakes.put(54, 34);
            snakes.put(62, 19);
            snakes.put(64, 60);
            snakes.put(69, 50);
            snakes.put(87, 24);
            snakes.put(91, 73);
            snakes.put(99, 78);
        }

        public void setPositions(int horsePosition, int elephantPosition) {
            this.horsePosition = horsePosition;
            this.elephantPosition = elephantPosition;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int boardSize = Math.min(getWidth() - 50, getHeight() - 50);
            int cell = boardSize / 10;
            int startX = (getWidth() - cell * 10) / 2;
            int startY = (getHeight() - cell * 10) / 2;

            drawBoard(g2, startX, startY, cell);
            drawLadders(g2, startX, startY, cell);
            drawSnakes(g2, startX, startY, cell);
            drawPlayers(g2, startX, startY, cell);
        }

        private void drawBoard(Graphics2D g2, int startX, int startY, int cell) {

            for (int i = 1; i <= 100; i++) {
                Point p = getCellTopLeft(i, startX, startY, cell);

                if (i % 2 == 0) {
                    g2.setColor(new Color(240, 220, 170));
                } else {
                    g2.setColor(new Color(190, 205, 125));
                }

                g2.fillRect(p.x, p.y, cell, cell);

                g2.setColor(new Color(70, 45, 20));
                g2.setStroke(new BasicStroke(2));
                g2.drawRect(p.x, p.y, cell, cell);

                g2.setFont(new Font("Arial", Font.BOLD, 16));
                g2.setColor(Color.BLACK);
                g2.drawString(String.valueOf(i), p.x + 8, p.y + 20);
            }

            g2.setStroke(new BasicStroke(8));
            g2.setColor(new Color(115, 65, 20));
            g2.drawRect(startX, startY, cell * 10, cell * 10);
        }

        private void drawLadders(Graphics2D g2, int startX, int startY, int cell) {

            for (Map.Entry<Integer, Integer> entry : ladders.entrySet()) {
                Point from = getCellCenter(entry.getKey(), startX, startY, cell);
                Point to = getCellCenter(entry.getValue(), startX, startY, cell);

                drawSingleLadder(g2, from, to);
            }
        }

        private void drawSingleLadder(Graphics2D g2, Point from, Point to) {

            double dx = to.x - from.x;
            double dy = to.y - from.y;
            double length = Math.sqrt(dx * dx + dy * dy);

            double offsetX = -dy / length * 13;
            double offsetY = dx / length * 13;

            int leftStartX = (int) (from.x + offsetX);
            int leftStartY = (int) (from.y + offsetY);
            int leftEndX = (int) (to.x + offsetX);
            int leftEndY = (int) (to.y + offsetY);

            int rightStartX = (int) (from.x - offsetX);
            int rightStartY = (int) (from.y - offsetY);
            int rightEndX = (int) (to.x - offsetX);
            int rightEndY = (int) (to.y - offsetY);

            g2.setStroke(new BasicStroke(8, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.setColor(new Color(95, 55, 20));
            g2.drawLine(leftStartX, leftStartY, leftEndX, leftEndY);
            g2.drawLine(rightStartX, rightStartY, rightEndX, rightEndY);

            g2.setStroke(new BasicStroke(4, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.setColor(new Color(220, 160, 70));

            for (int i = 1; i <= 6; i++) {
                double t = i / 7.0;

                int stepLeftX = (int) (leftStartX + (leftEndX - leftStartX) * t);
                int stepLeftY = (int) (leftStartY + (leftEndY - leftStartY) * t);

                int stepRightX = (int) (rightStartX + (rightEndX - rightStartX) * t);
                int stepRightY = (int) (rightStartY + (rightEndY - rightStartY) * t);

                g2.drawLine(stepLeftX, stepLeftY, stepRightX, stepRightY);
            }

            g2.setFont(new Font("Arial", Font.BOLD, 12));
            g2.setColor(new Color(20, 120, 30));
            g2.drawString("", from.x - 22, from.y + 30);
            g2.drawString("", to.x - 15, to.y - 20);
        }

        private void drawSnakes(Graphics2D g2, int startX, int startY, int cell) {

            for (Map.Entry<Integer, Integer> entry : snakes.entrySet()) {
                Point head = getCellCenter(entry.getKey(), startX, startY, cell);
                Point tail = getCellCenter(entry.getValue(), startX, startY, cell);

                drawSingleSnake(g2, head, tail);
            }
        }

        private void drawSingleSnake(Graphics2D g2, Point head, Point tail) {

            int controlX = (head.x + tail.x) / 2 + 45;
            int controlY = (head.y + tail.y) / 2 - 25;

            QuadCurve2D curve = new QuadCurve2D.Float(
                    head.x, head.y,
                    controlX, controlY,
                    tail.x, tail.y
            );

            g2.setStroke(new BasicStroke(18, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.setColor(new Color(40, 145, 45));
            g2.draw(curve);

            g2.setStroke(new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.setColor(new Color(20, 85, 25));
            g2.draw(curve);

            g2.setColor(new Color(45, 160, 50));
            g2.fillOval(head.x - 18, head.y - 18, 36, 36);

            g2.setColor(Color.WHITE);
            g2.fillOval(head.x - 8, head.y - 7, 7, 7);
            g2.fillOval(head.x + 4, head.y - 7, 7, 7);

            g2.setColor(Color.BLACK);
            g2.fillOval(head.x - 6, head.y - 5, 3, 3);
            g2.fillOval(head.x + 6, head.y - 5, 3, 3);

            g2.setColor(Color.RED);
            g2.setStroke(new BasicStroke(3));
            g2.drawLine(head.x, head.y + 14, head.x, head.y + 28);
            g2.drawLine(head.x, head.y + 28, head.x - 7, head.y + 35);
            g2.drawLine(head.x, head.y + 28, head.x + 7, head.y + 35);

            g2.setColor(new Color(30, 120, 35));
            g2.fillOval(tail.x - 7, tail.y - 7, 14, 14);

            g2.setFont(new Font("Arial", Font.BOLD, 12));
            g2.setColor(new Color(140, 20, 20));
            g2.drawString("", head.x - 20, head.y - 25);
            g2.drawString("", tail.x - 15, tail.y + 30);
        }

        private void drawPlayers(Graphics2D g2, int startX, int startY, int cell) {

            Point horse = getCellCenter(horsePosition, startX, startY, cell);
            Point elephant = getCellCenter(elephantPosition, startX, startY, cell);

            g2.setColor(new Color(0, 95, 255));
            g2.fillOval(horse.x - 28, horse.y - 5, 42, 42);

            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Serif", Font.BOLD, 34));
            g2.drawString("♞", horse.x - 18, horse.y + 28);

            g2.setColor(new Color(220, 40, 40));
            g2.fillOval(elephant.x - 8, elephant.y - 5, 42, 42);

            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Serif", Font.BOLD, 28));
            g2.drawString("🐘", elephant.x - 7, elephant.y + 27);
        }

        private Point getCellTopLeft(int number, int startX, int startY, int cell) {

            int index = number - 1;
            int rowFromBottom = index / 10;
            int col;

            if (rowFromBottom % 2 == 0) {
                col = index % 10;
            } else {
                col = 9 - (index % 10);
            }

            int visualRow = 9 - rowFromBottom;

            return new Point(startX + col * cell, startY + visualRow * cell);
        }

        private Point getCellCenter(int number, int startX, int startY, int cell) {
            Point topLeft = getCellTopLeft(number, startX, startY, cell);
            return new Point(topLeft.x + cell / 2, topLeft.y + cell / 2);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GameBoard());
    }
}